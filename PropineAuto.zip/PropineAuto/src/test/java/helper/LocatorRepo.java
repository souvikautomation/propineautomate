package helper;

import org.openqa.selenium.By;

/**
 * This Class contains the By element to be operated from the StepDefinition class
 * @author souvighosh
 *
 */
public class LocatorRepo {
	
	public By headerOne = By.xpath("//h1[contains(text(),'Date P')]");
	public By subHeader = By.xpath("//p[contains(text(),'Enter a')]");
	
	public By dateField = By.cssSelector("input[name='date']");  
	public By dateLabel = By.cssSelector("label");
	
	public By propineLogo = By.xpath("//img");
	public By submitButton = By.cssSelector("form[method='post'] > .btn.btn-default");	
	public By resultLabel = By.xpath("//h3[contains(text(),'Results')]");
	public By parsedDateContainer = By.xpath("//h3[contains(text(),'Results')]/following-sibling::div");
}
